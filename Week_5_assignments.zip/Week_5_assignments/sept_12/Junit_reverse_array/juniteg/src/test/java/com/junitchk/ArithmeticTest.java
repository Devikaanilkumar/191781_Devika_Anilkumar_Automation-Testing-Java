package com.junitchk;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;

@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class ArithmeticTest {

    private  Arithmetic arithmetic;

    @BeforeAll
    static void befallmet() {
        System.out.println("Before All method");
    }

    @BeforeEach
    void befeachmet() {
    	arithmetic= new Arithmetic();
        System.out.println("Before Each method");
    }

    @Test
    @Order(1)
    @Tag("feature1")
    void testMet() {
        Arithmetic arith = new Arithmetic();
        System.out.println("Test 1");
        int actual_val = arith.add(-3, -5);
        assertEquals(-8, actual_val, "Addition should work for negative values also");
    }

    @Disabled
    @Order(2)
    @Tag("feature1")
    void testAdd() {
    	
         System.out.println("Test 2");
        assertEquals(5, arithmetic.add(2, 3), "Addition should return the sum of two numbers");
    }

    @Test
    @Order(3)
    @Tag("feature1")
    void testSubtract() {
    	 System.out.println("Test 3");
        assertEquals(1, arithmetic.subtract(5, 4), "Subtraction should return the difference of two numbers");
    }

    @Test
    @Tag("feature2")
    void testMultiply() {
    	 System.out.println("Test 2");
        assertEquals(6, arithmetic.multiply(2, 3), "Multiplication should return the product of two numbers");
    }
    
    @Test
    @Tag("feature1")
    void meta() {
    	 System.out.println("Test array");
    	int []  arr = {11,22,33,44,55};
    	int [] actual_arr =	arithmetic.reverse(arr);
    	int [] expected_arr = {55,44,33,22,11};
    	assertArrayEquals(expected_arr, actual_arr, "Reverse of array while comparing" );
    	 
    }
    
    @Test
    @Tag("feature1")
    void testDivide() {
    	 System.out.println("Test 4");
        assertEquals(2, arithmetic.divide(6, 3), "Division should return the quotient of two numbers");
    }

    @Test
    @Tag("feature2")
    void testDivideByZero() {
    	 System.out.println("Test 5");
        ArithmeticException thrown = assertThrows(ArithmeticException.class, () -> arithmetic.divide(1, 0), "Division by zero should throw ArithmeticException");
        assertEquals("Cannot divide by zero", thrown.getMessage());
    }

    // Positive Test Case for max() method
    @Test
    @Tag("feature3")
    void testMaxPos() {
    	 System.out.println("Test 6");
        assertEquals(9.8, arithmetic.max(7.9, 9.8), "Max should return the larger of two numbers");
    }

    // Negative Test Case for max() method
    @Test
    @Tag("feature3")
    void testMaxNeg() {
    	 System.out.println("Test 7");
        assertNotEquals(6.7, arithmetic.max(6.7, 8.5), "Max should not return the smaller of two numbers");
    }
    
   @AfterEach
   void metafter() {
	   arithmetic=null;
	   System.out.println("AfterEach");
   }
   @AfterAll
   static void afterall() { 
       System.out.println("after all.......");
       }
}
