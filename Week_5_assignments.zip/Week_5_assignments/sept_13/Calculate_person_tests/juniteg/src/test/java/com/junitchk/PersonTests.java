package com.junitchk;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;

public class PersonTests {
	
private Person person;

@BeforeEach
void metbe()
{
	person=new Person("name1",34,10000);
	
}

@Test
void met()
{
	Person person_actual = person.addeligibility(10);
	
	assertEquals(11000,person_actual.getLoan_eligibility(),
			"Checking Loan eligibility,after incrementing 10 percent");
	Person person_expected = new Person("name1",34,11000);
	assertEquals(person_expected,person_actual,
			"Directly checking objects after incrementing Salary");
	}
}
