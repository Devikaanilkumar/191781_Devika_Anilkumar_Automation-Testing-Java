package com.junitchk;

public class Calculate {
int add(int a, int b) {
return a+b;
}
}
