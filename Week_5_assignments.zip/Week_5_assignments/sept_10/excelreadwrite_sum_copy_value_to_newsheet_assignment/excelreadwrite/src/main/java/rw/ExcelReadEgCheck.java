package rw;

import java.io.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelReadEgCheck {
    public static void main(String[] args) throws FileNotFoundException, IOException {
        // open file
        FileInputStream fis = new FileInputStream("./firstexcel.xlsx");

        // read workbook
        Workbook wbook = new XSSFWorkbook(fis);

        System.out.println("No. of sheets: " + wbook.getNumberOfSheets());

        int no_of_sheets = wbook.getNumberOfSheets();
        double value = 0;
        int no_of_rows = 0;
        Sheet st = null;

        
        
            // read sheet
            st = wbook.getSheetAt(0);

            no_of_rows = st.getPhysicalNumberOfRows();

            for (int i = 0; i < no_of_rows; i++) {
                // read rows
                Row row = st.getRow(i);

                int no_of_cols = row.getLastCellNum();

                for (int j = 0; j < no_of_cols; j++) {
                    // read cells
                    Cell cell = row.getCell(j);

                    // Make sure the cell contains numeric data
                    if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                        value += cell.getNumericCellValue();
                    }
                }
            }
        

        System.out.println("Sum is: " + value);
        fis.close();

       
        FileOutputStream fos = new FileOutputStream("./firstexcel.xlsx");

        
        Row row = st.createRow(no_of_rows);
        System.out.println("Created row at index: " + no_of_rows);
        Cell cell = row.createCell(0);
        cell.setCellValue(value);

       
        Sheet st2 = wbook.getSheet("SecondSheet");
        if (st2 == null) {
           
        	st2 = wbook.createSheet("SecondSheet");
            System.out.println("Created new sheet");
        }

       
        Row row9 = st2.getRow(0);
        if (row9 == null) {
            row9 = st2.createRow(0);
        }

        
        Cell cell9 = row9.getCell(0);
        if (cell9 == null) {
            cell9 = row9.createCell(0);
            cell9.setCellValue(0); 
        }

        
        double iter = cell9.getNumericCellValue();
        iter++;
        cell9.setCellValue(iter);

        System.out.println("Updated execution count ,no of executions :" + iter);

       
        wbook.write(fos);
        fos.close();

       
    }
}
