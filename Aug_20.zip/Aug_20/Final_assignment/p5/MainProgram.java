package p5;

import p6.Employee;
import p6.PermanentEmplyee;

public class MainProgram {

public static void main(String[] args) {
	final int x=10;// final as local variable
PermanentEmplyee pobj = new PermanentEmplyee(145.6f,"Addr1");
pobj.displayP();
System.out.println("second object\n");
PermanentEmplyee pobj1 = new PermanentEmplyee(111,"name111",245,"Addr1");
pobj1.displayP();
final Employee obj =new Employee();//final as object
obj.displaye();
System.out.println("final variable :"+x);
}

}