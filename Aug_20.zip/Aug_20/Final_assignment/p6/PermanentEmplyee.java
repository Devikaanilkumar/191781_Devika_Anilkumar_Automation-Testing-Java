package p6;

public class PermanentEmplyee extends Employee{
private float salary;
private String addr;
public PermanentEmplyee(float salary, String addr) {
super(); //calling base class default constructor
this.salary = salary;
this.addr = addr;
}
public PermanentEmplyee(int eid,String ename,float salary, String addr) {
super(eid,ename); //calling base class overridded constructor
this.salary = salary;
this.addr = addr;
}
public float getSalary() {
return salary;
}
public void setSalary(float salary) {
this.salary = salary;
}
public String getAddr() {
return addr;
}
public void setAddr(String addr) {
this.addr = addr;
}
public void displayP() {
displaye();
System.out.println("Employee salary : "+salary+"\nAddress : "+addr);
}
}