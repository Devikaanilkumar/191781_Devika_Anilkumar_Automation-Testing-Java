package p6;


public class Employee {
private int eid;
private String name;
public Employee(){
System.out.println("Default Constructor");
}
public final void message()
{
	System.out.println("final data member derived");
	}
public Employee(int eid, String name) {
System.out.println("Derived Constructor");
this.eid = eid;
this.name = name;
}

public int getEid() {
	
	
	
return eid;
}

public void setEid(int eid) {
this.eid = eid;
}

public String getName() {
return name;
}

public void setName(String name) {
this.name = name;
}
public void displaye() {
System.out.println("Employee id "+eid+"\nName "+name);
}

}

  