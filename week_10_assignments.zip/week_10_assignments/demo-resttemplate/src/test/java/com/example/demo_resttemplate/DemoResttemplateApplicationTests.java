package com.example.demo_resttemplate;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import java.util.stream.Stream;

import static java.lang.System.*;
import org.springframework.test.web.servlet.*;

import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.*;
@SpringBootTest
@AutoConfigureMockMvc
class DemoResttemplateApplicationTests {
	@Autowired
	private MockMvc mockMvc;
	
	
	@BeforeEach
	void met() {
		
	}
	
	private static Stream<Arguments> fetchTicketIds(){
		
		return Stream.of(Arguments.of(1,"sssssss","bbbbbbbb"),
				Arguments.of(2,"llllllll","ppppppppp"),
				Arguments.of(3,"wwwwwwwww","iiiiiiiiii"));
	}
	
	
	
	@ParameterizedTest
	@MethodSource("fetchTicketIds")
	void testGetTicket(int ticketid) throws Exception{
		//out.print(false);
		 ResultActions resultActions=mockMvc.perform(get("/redbus/"+ticketid))
				.andExpect(status().isOk())
				.andExpect(content().contentType(MediaType.APPLICATION_JSON))
		        .andExpect(jsonPath("$.fromplace").value("fromplace"))
		        .andExpect(jsonPath("$.toplace").value("toplace"));
		       // .andDo(print());
		 
		 String jsonresponse= resultActions.andReturn().getResponse().getContentAsString();
		 System.out.println("Json Response:"+jsonresponse);
		 //json string to java object
		/* ObjectMapper omapper = new ObjectMapper();
		 Ticket ticket = omapper.readValue(jsonresponse,Ticket.class);
		System.out.println("From Placeee"+ticket.getFromplace());	 
		*/
		 
	}



	


	//@Test
	@Disabled
	void testBookTicket() throws Exception {
	    mockMvc.perform(post("/redbus")
	        .contentType(MediaType.APPLICATION_JSON)
	        .content("{\"username\":\"user456\","
	                + "\"fromplace\":\"tuv\","
	                + "\"toplace\":\"klmn\","
	                + "\"email\":\"987652@gmail.com\","
	                + "\"price\":9876.5}"))
	        .andExpect(status().isCreated())
	        .andExpect(content().contentType(MediaType.APPLICATION_JSON))
	        .andDo(print())
	        .andExpect(jsonPath("$.username").value("user456"));
	       
	}
	
	//@Test
	@Disabled
	void testUpdateTicket() throws Exception {
	    mockMvc.perform(put("/redbus/17")
	        .contentType(MediaType.APPLICATION_JSON)
	        .content(
	        		//"{\"username\":\"user456\","+
	        		"{\"fromplace\":\"KOCHI\","
	                + "\"toplace\":\"BANGALORE\","
	                + "\"email\":\"dev@gmail.com\","
	                + "\"price\":7088.5}"))
	        .andExpect(status().isCreated());
	        
	       
	}
	//@Test
	@Disabled
	void cancelTicket() throws Exception {
	    mockMvc.perform(delete("/redbus/15"))
	       
	        .andExpect(status().isOk());
	        
	       
	}
}
