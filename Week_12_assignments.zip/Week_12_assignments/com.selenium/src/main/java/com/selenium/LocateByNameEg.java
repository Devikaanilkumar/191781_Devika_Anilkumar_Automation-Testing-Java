package com.selenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LocateByNameEg {
	public static void main(String[] args) throws Exception{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		
		//Create an instance of Chrome driver
		WebDriver driver = new ChromeDriver();
		
		//send get request for sample web page
		driver.get("C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByNameEg.html");
		
		WebElement usernameField = driver.findElement(By.name("username"));
		usernameField.sendKeys("myusername");
		Thread.sleep(5000);
		driver.quit();
	}
}
