package com.selenium;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LocateByNameEg2 {
	public static void main(String[] args) throws Exception{
		//chrome driver path
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Administrator\\Downloads\\chromedriver-win32\\chromedriver-win32\\chromedriver.exe");
		
		//Create an instance of Chrome driver
		WebDriver driver = new ChromeDriver();
		
		//send get request for sample web page
		driver.get("C:\\Users\\Administrator\\eclipse-workspace\\com.selenium\\src\\main\\resources\\LocateByNameEg2.html");
		
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(10));
		
		WebElement usernameField = wait.until(ExpectedConditions.visibilityOfElementLocated(By.name("username")));
		usernameField.sendKeys("someuser");
		
		WebElement ageField = driver.findElement(By.name("age"));
		ageField.sendKeys(String.valueOf(35));
		
		WebElement countryDropdown = driver.findElement(By.name("country"));
		countryDropdown.sendKeys("Canada");
		
		WebElement submitButton = driver.findElement(By.id("submitButton"));
		
		submitButton.click();
		
		Thread.sleep(2000);
		
		WebElement messageDiv =driver.findElement(By.id("message"));
		System.out.println("Message is:"+ messageDiv.getText());
		Thread.sleep(2000);
		driver.quit();
	}
}
