package p7;

import p6.Employee;

public class TemporaryEmployee extends Employee {
    private float hourlypay;
     private String company_adrr;
	public TemporaryEmployee(int eid, String name,float hourlypay,String company_adrr) {
		super(eid, name);
		this.hourlypay=hourlypay;
		this.company_adrr=company_adrr;
	}
		public void display()
		{
		displaye();
		System.out.println("Hourly Pay is"+hourlypay+"Company Address is"+company_adrr);
	}

}
