package com.example.demo_ticket.model;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonSetter;
import com.fasterxml.jackson.annotation.Nulls;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Email;

@Entity
public class Ticket {
	
	@Id
	@GeneratedValue(strategy= GenerationType.IDENTITY)
	private int id;
	
	@NotNull(message = "Username cant be blank")
	@Column
	private String username;

	@NotNull
	@Column
	private String fromplace;
	
	@NotNull
	@Column
	private String toplace;
	
	@DecimalMin("99.9")
	@DecimalMin("10000")
	@Column
	private float price;
	
	@DecimalMin("1")
	@DecimalMax("10")
	@Column
	private int no_seats;
	
	
	public int getNo_seats() {
		return no_seats;
	}

	public void setNo_seats(int no_seats) {
		this.no_seats = no_seats;
	}

	@NotNull
	@Email
	@Column
	private String email;
	
	
	public Ticket(int id, @NotNull(message = "Username cant be blank") String username, @NotNull String fromplace,
			@NotNull String toplace, @DecimalMin("99.9") float price, @DecimalMin("1") @DecimalMax("10") int no_seats,
			@NotNull @Email String email) {
		super();
		this.id = id;
		this.username = username;
		this.fromplace = fromplace;
		this.toplace = toplace;
		this.price = price;
		this.no_seats = no_seats;
		this.email = email;
	}

	

	

	public Ticket() {}
	
	

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public String getFromplace() {
		return fromplace;
	}

	public void setFromplace(String fromplace) {
		this.fromplace = fromplace;
	}

	public String getToplace() {
		return toplace;
	}

	public void setToplace(String toplace) {
		this.toplace = toplace;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Ticket [id=" + id + ", username=" + username + ", fromplace=" + fromplace + ", toplace=" + toplace
				+ ", price=" + price + ", no_seats=" + no_seats + ", email=" + email + "]";
	}
	


}
