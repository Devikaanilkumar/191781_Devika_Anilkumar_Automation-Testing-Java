package com.example.demo_rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoRestController {
  public DemoRestController()
  {
	  System.out.println("Constructor demo");
	  }
  @GetMapping("/abc")	
  String met() {
	  System.out.println("jjjjjjjjjj");
	  return " Hello World";
  }
  @GetMapping("/person")
  User getuser()
  {
	  return new User(1,"some user","some addr");
  }
}
